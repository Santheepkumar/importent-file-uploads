// Q3.Write a program that it takes numbers as input and separate the numbers by inserting dash(-) between two even numbers For example if numbers is 12345648 the output should be 123456-4-8.

// const one = 1234611;

var express = require("express");
var cors = require("cors");
var app = express();

app.use(cors());
app.use(express.json()); // for parsing application/json
app.use(express.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

app.use(express.static("public"));

const isEven = (num) => {
  const bool = num % 2 === 0;
  return bool;
};

// 1234437
const splitInbetweenDoubleEven = (n) => {
  var string = n.toString();
  var finalArr = [];

  for (var i = 0; i < string.length; i++) {
    const numOfChar = parseInt(string.charAt(i)); /* 1 */
    const lastEle = finalArr[finalArr.length - 1];

    if (isEven(numOfChar) && isEven(parseInt(lastEle))) {
      finalArr.push("-");
      finalArr.push(numOfChar.toString());
      // Array.prototype.push.apply(finalArr, ["-", numOfChar.toString()]);
    } else {
      finalArr.push(numOfChar.toString()); /* "1" */
    }
  }

  return finalArr.join("");
};

app.post("/q3", function (req, res) {
  const { number } = req.body;
  const converted = splitInbetweenDoubleEven(number);
  const resObj = { converted: converted };
  res.json(resObj);
});
function ammuIdhuDummyFunctionOriginalConvertionFunctionKuMathiko(str, let) {
  return 123;
}

app.post("/q12", (req, res) => {
  const { str, letr } = req.body;
  const count = ammuIdhuDummyFunctionOriginalConvertionFunctionKuMathiko(
    str,
    letr
  );
  const resObj = { count: count };
  res.json(resObj);
});

app.listen(8081, () => {
  console.log("Example app listening at http://%s:%s", 8081);
});
