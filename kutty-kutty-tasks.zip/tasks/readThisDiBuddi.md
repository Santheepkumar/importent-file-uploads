## Start the server in /task folder

- npm i && npm start

## Tasks

- Open each task folder to view htmls. example q3 folder will have q3's html and js.

- Dont forget to read the comments inside q12/buddi.html.

- And follow this structure create folders for all tasks .Use only one server di ok va.

# Miss you so much :) byee
