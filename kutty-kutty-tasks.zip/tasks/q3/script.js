const inputIt = document.getElementById("inputIt");
const output = document.getElementById("output");
const convert = document.getElementById("convert");

// const inputValue = parseInt(inputIt.value);

// alert(inputIt.value);
// console.log(inputValue);

convert.addEventListener("click", (e) => {
  e.preventDefault();

  fetch("http://localhost:8081/q3", {
    method: "post",
    body: JSON.stringify({ number: inputIt.value }),
    headers: { "Content-Type": "application/json" },
  })
    .then((r) => r.json())
    .then((res) => {
      output.innerHTML = res.converted;
    })
    .catch((e) => {
      console.log(e);
    });
});
